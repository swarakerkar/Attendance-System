<?php
include("../cors.php");
include "../db.php";

$dept_id = $_GET['department_id'];

$sql = "SELECT id, name FROM faculty WHERE department_id = '$dept_id'";
$result = $conn->query($sql);

$faculty = [];

while ($row = $result->fetch_assoc()) {
    $faculty[] = $row;
}

echo json_encode($faculty);
?>